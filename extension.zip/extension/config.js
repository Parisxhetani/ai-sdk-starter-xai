// Supabase project configuration for the extension popup.
const SUPABASE_URL = "https://apwtihxxaywskoipsctv.supabase.co"
const SUPABASE_ANON_KEY = "sb_publishable_ezx-KAOJLW8p8QJD3Mm7Wg_wnmwhmcK"

// Optional: set to true to log verbose messages in the popup console.
const DEBUG_LOGGING = false
